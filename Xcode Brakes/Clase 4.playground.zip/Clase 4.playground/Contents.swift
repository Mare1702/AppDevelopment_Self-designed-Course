import SwiftUI
import PlaygroundSupport

var contadorBoton = 0

var challengeButton = Button("Completado"){
    print("Felicidades, reto completado")
    contadorBoton = contadorBoton + 1
    print("Retos completados hasta ahora: \(contadorBoton)")
}

PlaygroundPage.current.setLiveView(challengeButton)

