import UIKit

import MapKit
import PlaygroundSupport

var mapView = MKMapView(frame: CGRect(x: 300, y: 400, width: 500, height: 300))

PlaygroundPage.current.liveView = mapView
