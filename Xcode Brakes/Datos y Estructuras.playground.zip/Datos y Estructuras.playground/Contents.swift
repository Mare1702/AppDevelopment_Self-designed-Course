import UIKit

struct persona {
    var apellido: String
    var edad: Int
    var mexicanx: Bool
}
Edgar.mexicanx = false

var Edgar = persona(apellido: "Orozco", edad: 21, mexicanx: true)
var x: Int

print(Edgar)

var amigo = Edgar.apellido
print(amigo)

Edgar.apellido = "Hernández"
print(Edgar.apellido)
