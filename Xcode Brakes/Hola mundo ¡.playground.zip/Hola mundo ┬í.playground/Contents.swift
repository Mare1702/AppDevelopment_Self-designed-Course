

print("Hola mundo")
