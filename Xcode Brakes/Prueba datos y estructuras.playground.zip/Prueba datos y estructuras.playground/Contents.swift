import UIKit


var nombre: ()
var x: Int

struct Challenge{
    var title: String
    var points: Int
    var mexicano: Bool
}
var noStraws = Challenge(title: "Hola", points: 4, mexicano: true)
var pickUpTrash = Challenge(title: "Adios", points: 6, mexicano: false)

print(noStraws)
print(pickUpTrash)

print("El número de puntos asignados a al reto hola son \(noStraws.points)")

noStraws.points = 7

print("El número de puntos asignados a al reto hola son \(noStraws.points)")
